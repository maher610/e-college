<?php 
include 'header.php';
?>
<body>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <p></p>
    <?php
    include 'config.php';
    ?>
    <div class="container rounded border-dark" style="background-color:#F5F5F5 ;">
        <p></p>
        <h3 class="text-center"><b>New Issue</b></h3>
        <p></p>
        <form>
            <div class="form-group row">
                <label for="inputName" class="col-sm-2 col-form-label">
                Name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputName" readonly value=<?php
                    $fullname="";
                    $name=mysqli_query($con,"select fullname from user_info where email = '{$_SESSION['email']}'" );
                    while ($row = mysqli_fetch_array($name)) {
                        $fullname=$fullname.$row['fullname']." ";
                    }
                    echo "'".$fullname."'";
                ?>>
                </div>
            </div>

            <div class="form-group row">
                <label for="inputCollege" class="col-sm-2 col-form-label">Matric Number</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputMatric" readonly value=<?php
                    $name=mysqli_query($con,"select matric from user_info where email = '{$_SESSION["email"]}'" );
                    while ($row = mysqli_fetch_array($name)) {
                        echo $row['matric'];
                    }
                ?>>
                </div>
            </div>

            <div class="form-group row">
                <label for="inputCollege" class="col-sm-2 col-form-label">Residential College</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputEmail" readonly value=
                    <?php
                    $colleges="";
                    $college=mysqli_query($con,"select r_college from user_info where email = '{$_SESSION["email"]}'" );
                    while ($row = mysqli_fetch_array($college)) {
                        $colleges=$colleges.$row['r_college']." ";
                    }
                    echo "'".$colleges."'";
                ?>>
                </div>
            </div>

            <div class="form-group row">
                <label for="inputContact" class="col-sm-2 col-form-label">Contact Number </label>
                <div class="col-sm-10">
                    <input type="number" class="form-control" readonly value=<?php
                    $phone=mysqli_query($con,"select phone from user_info where email = '{$_SESSION["email"]}'" );
                    while ($row = mysqli_fetch_array($phone)) {
                        echo $row['phone'];
                    }
                ?>>
                </div>
            </div>
            </form>
            <form action="reportcheck.php" method="post">
            <div class="form-group row">
                <label for="inputIssueCategory" class="col-sm-2 col-form-label">Issue Category</label>
                <div class="col-sm-10">
                    <select class="form-control" name="category">
                        <option value="" disabled selected>Select your issue category</option>
                        <option value="bedroom">Bedroom</option>
                        <option value="cafeteria">Cafeteria</option>
                        <option value="toilet">Toilet</option>
                        <option value="corridor">Corridor</option>
                        <option value="lift">Lift</option>
                        <option value="comittee room">Comittee Room</option>
                      </select>
                </div>
            </div>
            <div class="form-group row">
                <label for="inputIssueCategory" class="col-sm-2 col-form-label">Issue Type</label>
                <div class="col-sm-10">
                    <select class="form-control" name="rep_type">
                        <option value="" disabled selected>Select your issue type</option>
                        <option value="no-wifi">No wifi</option>
                        <option value="water-leaking">Water Leaking</option>
                        <option value="broken">Broken Things</option>
                        <option value="aircond-prob">Aircond-Problem</option>
                      </select>
                </div>
            </div>

            <div class="form-group row">
                <label for="inputDetails" class="col-sm-2 col-form-label">Details</label>
                <div class="col-sm-10">
                    <input type="textarea" class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Describe the issue" name="details"></textarea>
                </div>
            </div>

            <div class="form-group row">
                <label class="control-label col-sm-2" for="inputLocation">Issue Location</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="issue-location" placeholder="Enter the location" name="location">
                </div>
            </div>
            <br>
            <div class="text-center">
                <a class="block">
                    <button type="submit" name="reportcheck" class="btn btn-success">Submit</button>
                    <button href="reportlist.php" name="cancel_report" class="btn btn-danger">Cancel</button>
                </a>
            </div>
            <p><br><br></p>
        </form>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Confirmation of submission</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info" role="alert">
                        <div>Are you sure you want to submit the following report?</div>
                    </div>
                    <div class="text-center">
                                <button type="button" class="btn btn-success" >Confirm</button>
                                <button type="button" class="btn btn-danger" >Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal2 -->
    <div class="modal fade" id="myModal2" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Delete Report</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-success" role="alert">
                        <div>New report submitted</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal" onclick="javascript:window.location='report-list.html'">Close</button>
                </div>
            </div>
        </div>
    </div>
</body>
<?php
include_once 'footer.php';
?>
</html>