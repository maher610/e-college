<?php
  session_start();
  header("Location: report-list.php");
 ?>