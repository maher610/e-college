<?php
include 'config.php';
  if (isset($_POST['reportcheck'])) {
    #require 'config.php';
    $host = "localhost";
    $uname = "root";
    $pwd = "";
    $dbname = "ecollege";
  
    $con = new mysqli($host,$uname,$pwd,$dbname);
  
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
      }
      echo "Database Connected successfully <br><br>";

      #set timezone to Kuala Lumpur in database  
    date_default_timezone_set('Asia/Kuala_Lumpur');
    
    #create random reportID
    $reportID = rand(10000000,99999999);

    #fetch matric number from user to make it as a primary key
    session_start();
    $matric=mysqli_query($con,"select matric from user_info where email = '{$_SESSION["email"]}'" );
    while($row = mysqli_fetch_array($matric)){
    $matricNo = $row['matric'];}
    $email = $_SESSION['email'];
    $category = $_POST['category'];
    $rep_type = $_POST['rep_type'];
    $details = $_POST['details'];
    $location = $_POST['location'];
    $category = $_POST['category'];
    $date = date("Y-m-d h:i:sa");

    $sql = "INSERT INTO lodgereport(reportID, matric, category, rep_type, details, rep_location,dateLodged, email) VALUES ('$reportID','$matricNo','$category', '$rep_type', '$details', '$location', '$date', '$email')";
    
    #insert data into db test, all columns need to be filled
    #$sql ="INSERT INTO test(category) VALUES ('$category')";
    if ($con->query($sql) === TRUE) {
    } else {
        echo "Error: " . $sql . "<br>" . $con->error;
    }
    
    $con->close();
    header("Location: report-list.php");
    exit();
    }
    elseif(isset($_POST['cancel_report'])){
        header("Location: report-list.php");
    }
 ?>