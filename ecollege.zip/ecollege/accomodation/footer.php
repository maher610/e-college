<footer class="my-5 pt-1 text-muted text-center text-small">
    <p class="mb-1">© 2020 e-College - University of Malaya</p>
    <ul class="list-inline">
        <li class="list-inline-item"><a href="https://myum.um.edu.my/">MyUM</a></li>
        <li class="list-inline-item"><a href="https://maya.um.edu.my/sitsvision/wrd/siw_lgn">Maya</a></li>
        <li class="list-inline-item"><a href="https://spectrum.um.edu.my/">SpeCTRUM</a></li>
    </ul>
</footer>